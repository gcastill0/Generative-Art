<html>

<head>

</head>

    <style>
      body {
        margin: 0px;
        padding: 0px;
        border: 1px solid #9C9898;
      }
    </style>

<title>Splunk Javascript Test</title>

<body>

<script type="text/javascript" src="jquery.js"></script>

<script type="text/javascript" charset="utf-8">

    /* Function submitLoggerEvent
	** Paramams:
	** id: ID Specifies a unique id for the element in use
	*/

    function submitLoggerEvent(id) {

		// Treat as an object
        var jsonobj = document.getElementById(id);	

        // Obtain the writeable JSON key value pairs
		var jsonstr=JSON.stringify(getKeys(jsonobj));

		alert(jsonstr);

        // AJAX call to logger service
        $.ajax( {
           url: '/logger.php',
           type: 'POST',
          data: {data: jsonstr},
         });

    };

    /* Function getKeys
	** Paramams:
	** obj: Unique object for the element in use
	*/

    function getKeys(obj) {

		// Initialize variable
        var keys = {};

        // Record should be earmarked with date
		keys.date = Date();

        // For all property keys in the object
		// We are only going one level deep for this demo
        for(var key in obj){
		    try {			
		        var type = typeof(obj[key]);

				// Choose only those that are writeable and have an actual value
				if ((type == 'string' ) && ((obj[key] != null) && (obj[key] != ""))) {
				    keys[key] = obj[key];
				}
		    }
		    catch (err) {
				alert(err);		    
		    }
        }
		return keys;
    };

</script>

<P>
    <button type="button" id="button1" value="Button A" onclick="submitLoggerEvent('button1')">Button A</button>
    <button type="button" id="button2" value="Button B" onclick="submitLoggerEvent('button2')">Button B</button>
</P>

<P>
    <select id="select1" value="Selector A" onChange="submitLoggerEvent('select1')">
        <option value="Item 0" selected>Select an item
        <option value="Item 1">Item 1
        <option value="Item 2">Item 2
        <option value="Item 3">Item 3
    </select>
</P>

<P>

I'll buy it!  And I'll pay:
    <input type="text" id='dollar_amount' value="Dollar Amount"></input>
    <button type="button" id="button3" value="Button C" onclick="submitLoggerEvent('dollar_amount'),submitLoggerEvent('button3')">Buy It!</button>
</P>

</body>

</html>